package com.example.robinska191.spyfall;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class GamePrep extends Activity {
int curPlayerNum;
int numPlayers;
int time;
Button next;
TextView nameOutput;
TextView locationOutput;
TextView roleOutput;
String[] playerNames;
String spyPlayer;
String location;
String[] roleList;
String curPlayer;
boolean isSpy;
boolean revealed;
Resources res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_prep);
        curPlayerNum = getIntent().getIntExtra("curPlayerNum", 0);
        numPlayers = getIntent().getIntExtra("numPlayers", 0);
        //time = getIntent().getIntExtra("time", 5);
        playerNames = getIntent().getStringArrayExtra("playerNames");
        System.out.println(playerNames.length);
        spyPlayer = getIntent().getStringExtra("spyPlayer");
        location = getIntent().getStringExtra("location");
        roleList = getIntent().getStringArrayExtra("roleList");
        //TESTING VALUES ONLY DELETE WHEN DONE

        time = Integer.parseInt(getIntent().getStringExtra("time"));
        curPlayer = playerNames[curPlayerNum];
        isSpy = curPlayer.equals(spyPlayer);
        next = findViewById(R.id.revealButton);
        nameOutput = findViewById(R.id.nameOutput);
        locationOutput = findViewById(R.id.locationOutput);
        roleOutput = findViewById(R.id.roleOutput);
        res = getResources();
        next.setText(res.getText(R.string.reveal));
        nameOutput.setText(curPlayer);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(curPlayerNum + 1 == playerNames.length && revealed == true)) {
                    if (!revealed) {
                        reveal();
                        revealed = true;
                        if(curPlayerNum+1 != playerNames.length) {
                            next.setText(res.getString(R.string.nextPlayer));
                        }
                        else
                        {
                            next.setText(res.getString(R.string.begin));
                        }
                    }
                    else
                        {
                        nextPlayer();
                        revealed = false;
                        next.setText(res.getString(R.string.reveal));
                    }
                }
                else
                {
                    startGame();
                }
            }
        });
    }
    public void reveal()
    {
        if(isSpy)
        {
            locationOutput.setText(res.getString(R.string.location)+res.getString(R.string.unknown)+"");
            roleOutput.setText(res.getString(R.string.role)+res.getString(R.string.spy)+"");
        }
        else
        {
            locationOutput.setText(res.getString(R.string.location)+location);
            roleOutput.setText(res.getString(R.string.role)+roleList[(int)(Math.random()*roleList.length)]);
        }
    }
    public void nextPlayer()
    {
        curPlayerNum++;
        curPlayer = playerNames[curPlayerNum];
        isSpy = curPlayer.equals(spyPlayer);
        nameOutput.setText(curPlayer);
        locationOutput.setText(res.getString(R.string.location));
        roleOutput.setText(res.getString(R.string.role));

    }
    public void startGame()
    {
        Intent intent = new Intent(this, GameTimer.class);
        intent.putExtra("time", time);
        intent.putExtra("spyName", spyPlayer);
        intent.putExtra("location", location);
        intent.putExtra("playerNames", playerNames);
        intent.putExtra("numberPlayers",numPlayers);
        startActivityForResult(intent,2);
    }

}
