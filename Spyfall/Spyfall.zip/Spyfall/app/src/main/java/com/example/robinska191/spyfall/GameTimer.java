package com.example.robinska191.spyfall;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.app.Activity;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class GameTimer extends Activity {
TextView timer;
CountDownTimer countdown;
int time;
int secondsLeft;
Button finishButton;
Button pauseButton;
String timeString;
String spyName;
String location;
String[] playerNames;
int numPlayers;
boolean pause;
Resources res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_timer);
        timer = findViewById(R.id.gameTimer);
        time = getIntent().getIntExtra("time", 5);
        spyName = getIntent().getStringExtra("spyName");
        location = getIntent().getStringExtra("location");
        playerNames = getIntent().getStringArrayExtra("playerNames");
        numPlayers = getIntent().getIntExtra("numPlayers",3);
        secondsLeft = time*60;
        finishButton = findViewById(R.id.finishButton);
        pauseButton = findViewById(R.id.pauseButton);
        res = getResources();
        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                endGame();
            }
        });
        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseUnpause();
            }
        });
        createCountDown();
    }
    public void updateTimeString(int secondsUntilDone)
    {
        int minutes = secondsUntilDone/60;
        int seconds = secondsUntilDone % 60;
        if(minutes < 10)
        {
            timeString = "0"+minutes+":";
        }
        else
        {
            timeString = minutes+":";
        }
        if(seconds< 10)
        {
            timeString = timeString+"0"+seconds;
        }
        else
        {
            timeString = timeString+seconds;
        }
        timer.setText(timeString);
    }
    public void createCountDown()
    {
        countdown = new CountDownTimer(secondsLeft*1000,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                secondsLeft--;
                updateTimeString(secondsLeft);

            }
            @Override
            public void onFinish() {
                endGame();
            }
        }.start();
    }
    public void endGame()
    {
        Intent intent = new Intent(this, EndGame.class);
        intent.putExtra("playerNames", playerNames);
        intent.putExtra("numPlayers", numPlayers);
        intent.putExtra("spyName", spyName);
        intent.putExtra("location", location);
        intent.putExtra("time", time);
        startActivity(intent);
        finish();
    }
    public void pauseUnpause()
    {
        if(!pause)
        {
            countdown.cancel();
            pauseButton.setText(res.getString(R.string.unpause));
            pause = true;
        }
        else
        {
            createCountDown();
            pause = false;
            pauseButton.setText(res.getString(R.string.pause));
        }
    }

}
