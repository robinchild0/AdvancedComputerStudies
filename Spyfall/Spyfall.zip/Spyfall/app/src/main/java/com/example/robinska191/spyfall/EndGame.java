package com.example.robinska191.spyfall;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.HashMap;

public class EndGame extends Activity {
Button menu;
Button playAgain;
TextView spyOutput;
TextView locationTextOuput;
String spyName;
String location;
String[] playerNames;
int time;
HashMap<String,String[]> locationRoles;
int numPlayers;
Resources res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_game);
        res = getResources();
        locationRoles = new HashMap<>();
        menu = findViewById(R.id.menu);
        playAgain = findViewById(R.id.playAgain);
        spyOutput = findViewById(R.id.spyOutput);
        locationTextOuput = findViewById(R.id.locationTextOutput);
        spyName = getIntent().getStringExtra("spyName");
        location = getIntent().getStringExtra("location");
        playerNames = getIntent().getStringArrayExtra("playerNames");
        numPlayers = getIntent().getIntExtra("numPlayers", 3);
        spyOutput.setText(spyName);
        locationTextOuput.setText(location);
        time = getIntent().getIntExtra("time", 5);
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toMenu();
            }
        });
        playAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                replay();
            }
        });

    }
    public void toMenu()
    {
        Intent intent = new Intent(this, GameMenu.class);
        startActivity(intent);
        finish();
    }
    public void replay()
    {
        buildHashMap();
        int ranNum = (int)(Math.random()*playerNames.length);
        String location = res.getStringArray(R.array.location)[(int)(Math.random()*res.getStringArray(R.array.location).length)];
        String[] roleList = locationRoles.get(location);
        Intent intent = new Intent(this, GamePrep.class);
        intent.putExtra("location", location);
        intent.putExtra("roleList", roleList);
        intent.putExtra("spyPlayer", playerNames[ranNum]);
        intent.putExtra("time", time+"");
        intent.putExtra("playerNames", playerNames);
        intent.putExtra("numPlayers", numPlayers);
        intent.putExtra("curPlayerNum", 0);
        startActivity(intent);
        finish();
    }
    public void buildHashMap()
    {
        locationRoles.put("Beach",res.getStringArray(R.array.beachRoles));
        locationRoles.put("Broadway Theater", res.getStringArray(R.array.theatreRoles));
        locationRoles.put("Casino" , res.getStringArray(R.array.casinoRoles));
        locationRoles.put("Circus Tent", res.getStringArray(R.array.circusRoles));
        locationRoles.put("Bank", res.getStringArray(R.array.bankRoles));
        locationRoles.put("Cathedral", res.getStringArray(R.array.cathedralRoles));
        locationRoles.put("Office", res.getStringArray(R.array.officeRoles));
        locationRoles.put("Crusaders' Army", res.getStringArray(R.array.armyRoles));
        locationRoles.put("Hospital", res.getStringArray(R.array.hospitalRoles));
        locationRoles.put("Hotel", res.getStringArray(R.array.hotelRoles));
        locationRoles.put("Military Base", res.getStringArray(R.array.militaryRoles));
        locationRoles.put("Train",res.getStringArray(R.array.trainRoles));
        locationRoles.put("Pirate Ship", res.getStringArray(R.array.pirateRoles));
        locationRoles.put("Polar Station", res.getStringArray(R.array.polarRoles));
        locationRoles.put("Police Station", res.getStringArray(R.array.policeRoles));
        locationRoles.put("Restaurant", res.getStringArray(R.array.restaurantRoles));
        locationRoles.put("Gas Station",res.getStringArray(R.array.gasRoles));
        locationRoles.put("Space Station", res.getStringArray(R.array.spaceRoles));
        locationRoles.put("Submarine", res.getStringArray(R.array.submarineRoles));
        locationRoles.put("World War II Battalion", res.getStringArray(R.array.battalionRoles));
    }

}
