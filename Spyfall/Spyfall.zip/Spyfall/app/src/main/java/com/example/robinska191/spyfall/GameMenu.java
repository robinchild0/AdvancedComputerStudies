package com.example.robinska191.spyfall;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class GameMenu extends Activity {
Button startGame;
Spinner timeSelection;
Button submitName;
EditText enterName;
TextView namesList;
//TextView debugOutput;
HashMap<String, String[]> locationRoles;
int time = 5;
int numPlayers;
String nameOutput;
ArrayList<String> playerNames;
Resources res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_menu);
        res = getResources();
        numPlayers = 0;
        namesList = findViewById(R.id.namesList);
        playerNames = new ArrayList<>(8);
        nameOutput = res.getString(R.string.current_players);
        startGame = findViewById(R.id.startGame);
        timeSelection = findViewById(R.id.timeSpinner);
        submitName = findViewById(R.id.submitName);
        enterName = findViewById(R.id.nameBox);
        //debugOutput = findViewById(R.id.debugOutput);
        submitName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nameSubmitted();
            }
        });
        startGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playGame();
            }
        });

        locationRoles = new HashMap<>();
        buildHashMap();

    }
    public void buildHashMap()
    {
        locationRoles.put("Beach",res.getStringArray(R.array.beachRoles));
        locationRoles.put("Broadway Theater", res.getStringArray(R.array.theatreRoles));
        locationRoles.put("Casino" , res.getStringArray(R.array.casinoRoles));
        locationRoles.put("Circus Tent", res.getStringArray(R.array.circusRoles));
        locationRoles.put("Bank", res.getStringArray(R.array.bankRoles));
        locationRoles.put("Cathedral", res.getStringArray(R.array.cathedralRoles));
        locationRoles.put("Office", res.getStringArray(R.array.officeRoles));
        locationRoles.put("Crusaders' Army", res.getStringArray(R.array.armyRoles));
        locationRoles.put("Hospital", res.getStringArray(R.array.hospitalRoles));
        locationRoles.put("Hotel", res.getStringArray(R.array.hotelRoles));
        locationRoles.put("Military Base", res.getStringArray(R.array.militaryRoles));
        locationRoles.put("Train",res.getStringArray(R.array.trainRoles));
        locationRoles.put("Pirate Ship", res.getStringArray(R.array.pirateRoles));
        locationRoles.put("Polar Station", res.getStringArray(R.array.polarRoles));
        locationRoles.put("Police Station", res.getStringArray(R.array.policeRoles));
        locationRoles.put("Restaurant", res.getStringArray(R.array.restaurantRoles));
        locationRoles.put("Gas Station",res.getStringArray(R.array.gasRoles));
        locationRoles.put("Space Station", res.getStringArray(R.array.spaceRoles));
        locationRoles.put("Submarine", res.getStringArray(R.array.submarineRoles));
        locationRoles.put("World War II Battalion", res.getStringArray(R.array.battalionRoles));
    }
    public void nameSubmitted()
    {

        String curName = enterName.getText().toString();
        if(curName.equals(""))
        {
            Toast.makeText(this, res.getString(R.string.emptyToast),Toast.LENGTH_SHORT).show();
        }
        else
        {
            boolean good = true;
            for(int i = 0; i<playerNames.size()&& good; i++)
            {
                if(curName.equals(playerNames.get(i)))
                {
                    good = false;
                    Toast.makeText(this,res.getString(R.string.repeatNameToast),Toast.LENGTH_SHORT).show();
                }
            }
            if(good)
            {
                playerNames.add(curName);
                numPlayers++;
                nameOutput = nameOutput + curName + "\n";
                namesList.setText(nameOutput);
            }
            enterName.setText("");
        }

        //debugOutput.setText((String)timeSelection.getSelectedItem());
    }
    public void playGame()
    {
        if(playerNames.size() >= 3)
        {
            int ranNum = (int) (Math.random() * playerNames.size());
            String location = res.getStringArray(R.array.location)[(int) (Math.random() * res.getStringArray(R.array.location).length)];
            String baseTime = (String) timeSelection.getSelectedItem();
        /*if(baseTime != null && !baseTime.equals(""))
        {
            time = Integer.getInteger(baseTime);
        }*/
            Intent gamePrep = new Intent(GameMenu.this, GamePrep.class);
            gamePrep.putExtra("time", (String) timeSelection.getSelectedItem());
            gamePrep.putExtra("playerNames", playerNames.toArray(new String[playerNames.size()]));
            gamePrep.putExtra("numPlayers", numPlayers);
            gamePrep.putExtra("spyPlayer", playerNames.get(ranNum));
            gamePrep.putExtra("location", location);
            gamePrep.putExtra("roleList", locationRoles.get(location));
            gamePrep.putExtra("curPlayerNum", 0);
            startActivity(gamePrep);
        }
        else
        {
            Toast.makeText(this, res.getString(R.string.toFewToast), Toast.LENGTH_SHORT ).show();
        }
    }


}
